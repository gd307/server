import os
import numpy as np
from tensorflow.keras.models import load_model
import matplotlib.pyplot as plt
#from wifilib import get_scale_csi, read_bf_file
from get_csi_ratio import get_ratio
import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


def extract_features(csi_data):
    # 使用 unwrap 展开相位
    #unwrapped_phases = np.unwrap(np.angle(csi_data), axis=0)
    # 应用 Savitzky-Golay 滤波
    #csi_data = savgol_filter(csi_data, SEGMENT_LENGTH, 2, axis=0)
    #np_csi_data_unwrapped = np.abs(csi_data) * np.exp(1j * smoothed_phases)
        
    # 获取比率

    x_ratio = get_ratio(csi_data)

    csi_data2=csi_data.reshape(csi_data.shape[0],-1)

    x_ratio2 = x_ratio.reshape(x_ratio.shape[0], -1)

    # 提取幅度和相位信息
    real_csi = np.abs(x_ratio2)
    imag_csi = np.angle(x_ratio2)
   
    real_csi2=x_ratio2.real
    imag_csi2=x_ratio2.imag

    # 计算CSI差分
    #real_csi_diff = np.diff(real_csi, axis=1)
    #imag_csi_diff = np.diff(imag_csi, axis=1)
  
    # 计算傅里叶变换
    #fft_real = np.abs(fft(csi_data2.real, axis=1))
    #fft_imag = np.abs(fft(csi_data2.imag, axis=1))
    

    # 计算统计特征
    real_mean = np.mean(real_csi, axis=1)
    real_mean=real_mean.reshape(real_mean.shape[0],1)
  
    real_std = np.std(real_csi, axis=1)
    real_std=real_std.reshape(real_std.shape[0],1)
    imag_mean = np.mean(imag_csi, axis=1)
    imag_mean=imag_mean.reshape(imag_mean.shape[0],1)
    imag_std = np.std(imag_csi, axis=1)
    imag_std=imag_std.reshape(imag_std.shape[0],1)
  
    # 计算功率谱密度

    #_,psd_real = welch(real_csi, axis=1)

    #_,psd_imag = welch(imag_csi, axis=1)

    # 组合特征
    features = np.concatenate([
        real_csi,imag_csi,real_csi2,imag_csi2,real_mean,real_std,imag_mean,imag_std
        #real_csi, imag_csi, real_csi_diff, imag_csi_diff, real_mean, real_std,imag_mean,imag_std#,psd_real,psd_imag
        #fft_real, fft_imag, real_mean[:, np.newaxis], real_std[:, np.newaxis], 
      #  imag_mean[:, np.newaxis], imag_std[:, np.newaxis], psd_real, psd_imag
    ], axis=-1)
    
    feature_csi=features.reshape(features.shape[0],(features.shape[1]//4),4)
    return feature_csi

def pre_csi(rawcsi):
    
    np_csi_data = rawcsi.reshape(rawcsi.shape[0],rawcsi.shape[2],rawcsi.shape[3],rawcsi.shape[1])
    csi_feature=extract_features(np_csi_data)
    reshape_csi = np.expand_dims(csi_feature, axis=0)
  
    return reshape_csi

def load_label_encoder():
    # 创建一个手动的标签编码器
    classes = np.load('label_classes.npy')  # 假设标签编码器的类保存为一个numpy文件
    label_encoder = {cls: idx for idx, cls in enumerate(classes)}
    reverse_label_encoder = {idx: cls for idx, cls in enumerate(classes)}
    return label_encoder, reverse_label_encoder

def load_model_and_encoder():
    model = load_model('best_model.h5')
    label_encoder, reverse_label_encoder = load_label_encoder()
    return model, label_encoder, reverse_label_encoder



# 实时预测和显示
def real_time_predict(csi_now,model, label_encoder, reverse_label_encoder):

    csi_data = pre_csi(csi_now)

    predictions = model.predict(csi_data)
    predicted_classes = np.argmax(predictions, axis=1)
    predicted_coords = [reverse_label_encoder[idx] for idx in predicted_classes]
    predicted_coords = np.array([list(map(int, coord.split('_'))) for coord in predicted_coords])
    last_predicted_coords = predicted_coords  # 更新最后的预测结果
    return last_predicted_coords


