# -*- coding: utf-8 -*-
"""
Created on Wed May  8 23:21:07 2024

@author: MSI-S14
"""
import numpy as np

def get_ratio(original_csi):
    frame=original_csi.shape[0];
    subcarrier_index=original_csi.shape[3];
    Ntx=original_csi.shape[1];
    Nrx=original_csi.shape[2];
    antenna_pair=Ntx*Nrx;
    
    csi_antpair = np.zeros((frame,subcarrier_index,antenna_pair),dtype = 'complex_');
    antpair_index = 0;
    for i in range(Ntx):
        for j in range(Nrx):
            csi_antpair[:,:,antpair_index] = original_csi[:,i,j,:];
            antpair_index = antpair_index+1;

    ratio_pair = antenna_pair*(antenna_pair-1);

    csi_ratio = np.zeros((frame,subcarrier_index,ratio_pair),dtype = 'complex_');
    ratio_index = 0;

    for i in range(antenna_pair):
        for j in range(antenna_pair):
            if i != j:
                
                csi_ratio_now = csi_antpair[:,:,i] / csi_antpair[:,:,j];
                csi_ratio[ :, :,ratio_index] = csi_ratio_now;
                ratio_index += 1;
    
    
    threshold = 1000  # Threshold value

    # Create boolean masks for real and imaginary parts exceeding the threshold
    real_part_mask = np.abs(csi_ratio.real) > threshold
    imaginary_part_mask = np.abs(csi_ratio.imag) > threshold

    # Set complex numbers where either the real or imaginary part exceeds the threshold to 0
    csi_ratio[real_part_mask | imaginary_part_mask] = 0

    nan_real_part = np.isnan(csi_ratio.real)
    nan_imaginary_part = np.isnan(csi_ratio.imag)

    csi_ratio[nan_real_part | nan_imaginary_part ] = 0

    #csi_ratio = np.nan_to_num(csi_ratio, nan=0)   #把ratio中包含nan的数变成0 
       
    return csi_ratio

def csi_ratio_flat(csi_data):
    csi_data_flat = csi_data.reshape(csi_data.shape[0], -1)
    csi_data_flat_abs = np.abs(csi_data_flat.real)
    return csi_data_flat_abs