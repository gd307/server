#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Plot CSI (Linux 802.11n CSI Tool, nexmon_csi) in real time

Usage:
    1. python3 csirealtime.py
    2. python3 csiserver.py ../material/5300/dataset/sample_0x5_64_3000.dat 3000 500
"""

#import essential packages
import socket
import threading
import csiread
import matplotlib.animation as animation
import matplotlib.pyplot as plt
import numpy as np
import queue
import os  # For beep command on Linux and macOS
import pandas as pd
from datetime import datetime
from get_model import real_time_predict, load_model_and_encoder
from scipy.stats import mode

#number of data samples at each batch
cache_len = 20
#number of receiver
Nrx = 3
#number of transmitter
Ntx = 3

csi_list = [np.full((30, Nrx, Ntx), np.nan) for _ in range(cache_len)]
mutex = threading.Lock()
#temp data queue to store csi data
data_queue = queue.Queue()
#temp data queue to store predicted location
plot_queue = queue.Queue()

# Predefined coordinates list for alarm
alarm_coords = np.array([[2, 0],[8,0]])

# Define vote count for majority voting
#to increase final localization accuracy, we do a majority vote to get the final location,
#you can change the vote number here
vote_count = 5
votes = []

# Create a DataFrame to save prediction results and timestamps
#here is the address for save the predicted location and time
results_df = pd.DataFrame(columns=['Time', 'X', 'Y'])
output_file='loc.csv'

# Define a function to play an alarm sound, you can change the alarm duration and frequency
def play_alarm_sound(frequency=1000, duration=1000):
    os.system(f'play -nq -t alsa synth {duration/1000} sine {frequency}')
    # Or use beep
    # os.system(f'beep -f {frequency} -l {duration}')

#main class for receiving csi data from receiver
class GetDataThread(threading.Thread):
    def __init__(self, device):
        super(GetDataThread, self).__init__()
        #listen to port number 10000
        self.address_des = ('0.0.0.0', 10000)
        if device == 'intel':
            self.csidata = csiread.Intel(None, Nrx, Ntx)

    def run(self):
        self.update_background()

    def update_background(self):
        global mutex, csi_list
        count = 0
        #receive the csi from port and store at csi_list
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.bind(self.address_des)
            while True:
                data, address_src = s.recvfrom(4096)
                msg_len = len(data)
                code = self.csidata.pmsg(data)
                if code == 0xbb:  # intel
                    scaled_csi_sm = self.csidata.get_scaled_csi()
                    tem_time = self.csidata.timestamp_low
                    mutex.acquire()
                    csi_list.pop(0)
                    csi_list.append(scaled_csi_sm[0])
                    mutex.release()
                    count += 1

                # Once we receive 100, start algorithm
                #put the csi data in data_queue for running algorithm
                if count % cache_len == 0:
                    np_csi = np.array(csi_list)
                    mutex.acquire()
                    data_queue.put(np_csi)
                    mutex.release()
                    print('receive %d bytes [msgcnt=%u]' % (msg_len, count))
                    #reset count and reset csi_list
                    csi_list = [np.full((30, Nrx, Ntx), np.nan) for _ in range(cache_len)]
                    count = 0

#class for location prediction algorithm
class ProcessThread(threading.Thread):
    def __init__(self):
        super(ProcessThread, self).__init__()
        self.model, self.label_encoder, self.reverse_label_encoder = load_model_and_encoder()

    def run(self):
        global votes, results_df
        while True:
            #get the csi data from queue and start algorithm
            np_csi_now = data_queue.get()
            # input raw_csi and machine learning model,output location (x,y)
            pre = real_time_predict(np_csi_now, self.model, self.label_encoder, self.reverse_label_encoder)
            votes.append(pre)
            #plot_queue.put(pre)
            
            #gather the output location and do majority vote to get the final location
            
            # If the number of votes reaches the vote count
            if len(votes) >= vote_count:
                # Use majority voting method
                major_vote = self.major_vote(votes)
                print(major_vote)
                #save the final location in queue for drawing.
                plot_queue.put(major_vote)
                
                #here is the code to save location (x,y) and time
                # Save prediction coordinates and current time to DataFrame
                current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                for coord in major_vote:
                    results_df.loc[len(results_df)] = [current_time, coord[0], coord[1]]
                
                # Save to CSV file in real-time
                results_df.to_csv(output_file, index=False)
                
                votes = []  # Reset votes list
         
    #this function is for majority vote            
    def major_vote(self, votes):
        """Majority voting method to determine the final prediction."""
        votes_array = np.array(votes)
        major_vote = mode(votes_array,axis=0,keepdims=True).mode[0]
        return major_vote

#this function is for plot, you can delete plot for aws
def realtime_plot_intel():
    fig, ax = plt.subplots()
    plt.title('CSI Amplitude')
    plt.xlabel('X')
    plt.ylabel('Y')
    ax.set_ylim(0, 10)
    ax.set_xlim(0, 10)
    scatter = ax.scatter([], [])

    def init():
        scatter.set_offsets(np.c_[[], []])
        return scatter,

    def animate(i):
        if not plot_queue.empty():
            pre = plot_queue.get()
            xdata = [coord[0] for coord in pre]
            ydata = [coord[1] for coord in pre]
            scatter.set_offsets(np.c_[xdata, ydata])

            # Check if the predicted coordinates are within the alarm range
            for x, y in zip(xdata, ydata):
                for alarm_coord in alarm_coords:
                    distance = np.linalg.norm([x - alarm_coord[0], y - alarm_coord[1]])
                    if distance < 1:
                        print(f"Alarm! Close to predefined coordinate {alarm_coord} with distance {distance:.2f}")
                        play_alarm_sound(frequency=2000, duration=500)  # Adjust frequency and duration

        else:
            print("plot_queue is empty")
        return scatter,

    ani = animation.FuncAnimation(fig, animate, init_func=init, frames=np.arange(0,1000), interval=1000, blit=True, cache_frame_data=False)
    plt.show()

#here is where we start the whole code
def realtime_plot(device):
    task = GetDataThread(device)
    task.start()
    process_thread = ProcessThread()
    process_thread.start()
    realtime_plot_intel()

if __name__ == '__main__':
    realtime_plot('intel')
